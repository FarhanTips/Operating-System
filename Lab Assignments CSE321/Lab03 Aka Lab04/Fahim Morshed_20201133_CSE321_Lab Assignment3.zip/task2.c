#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <sys/wait.h>
#include <errno.h>


struct msg {
    long int type;
    char txt[6];
};

int main() {
    key_t key = ftok(".", 'a');
    int msgid = msgget(key, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget");
        exit(1);
    }

    printf("Please enter the workspace name:\n");
    char workspace[20];
    scanf("%s", workspace);

    if (strcmp(workspace, "cse321") != 0) {
        printf("Invalid workspace name\n");
        exit(1);
    }

    struct msg login_msg;
    login_msg.type = 1; 
    strcpy(login_msg.txt, workspace);
    if (msgsnd(msgid, &login_msg, sizeof(login_msg), 0) == -1) {
        perror("msgsnd");
        exit(1);
    }
    printf("Workspace name sent to otp generator from log in: %s\n", login_msg.txt);
    printf("\n");
    printf("\n");

    // child process OTP generator
    pid_t otp_pid = fork();
    if (otp_pid == -1) {
        perror("fork");
        exit(1);
    }
    if (otp_pid == 0) { 
        struct msg otp_msg;
        if (msgrcv(msgid, &otp_msg, sizeof(otp_msg), 1, 0) == -1) {
            perror("msgrcv");
            exit(1);
        }
        printf("OTP generator received workspace name from log in: %s\n", otp_msg.txt);
        printf("\n");
        printf("\n");

        pid_t otp = getpid();
        sprintf(otp_msg.txt, "%d", otp);

        otp_msg.type = 2; 
        if (msgsnd(msgid, &otp_msg, sizeof(otp_msg), 0) == -1) {
            perror("msgsnd");
            exit(1);
        }
        printf("OTP sent to log in from OTP generator: %s\n", otp_msg.txt);

        otp_msg.type = 3; 
        if (msgsnd(msgid, &otp_msg, sizeof(otp_msg), 0) == -1) {
            perror("msgsnd");
            exit(1);
        }
        printf("OTP sent to mail from OTP generator: %s\n", otp_msg.txt);

        exit(0);
    }

    wait(NULL);

    struct msg login_otp_msg;
    if (msgrcv(msgid, &login_otp_msg, sizeof(login_otp_msg), 2, 0) == -1) {
        perror("msgrcv");
        exit(1);
    }
    printf("Log in received OTP from OTP generator: %s\n", login_otp_msg.txt);

    struct msg mail_otp_msg;
    if (msgrcv(msgid, &mail_otp_msg, sizeof(mail_otp_msg), 3, 0) == -1) {
        perror("msgrcv");
        exit(1);
    }
    printf("Mail received OTP from OTP generator: %s\n", mail_otp_msg.txt);

    pid_t mail_pid = fork();
    if (mail_pid == -1) {
        perror("fork");
        exit(1);
    }
    if (mail_pid == 0) { 
        mail_otp_msg.type = 4;
        if (msgsnd(msgid, &mail_otp_msg, sizeof(mail_otp_msg), 0) == -1) {
            perror("msgsnd");
            exit(1);
        }
        printf("OTP sent to log in from mail: %s\n", mail_otp_msg.txt);

        exit(0);
    }

    wait(NULL);

    struct msg login_mail_msg;
    if (msgrcv(msgid, &login_mail_msg, sizeof(login_mail_msg), 4, 0) == -1) {
        perror("msgrcv");
        exit(1);
    }
    printf("Log in received OTP from mail: %s\n", login_mail_msg.txt);

    if (strcmp(login_otp_msg.txt, login_mail_msg.txt) == 0) {
        printf("OTP Verified\n");
    } else {
        printf("OTP Incorrect\n");
    }

    if (msgctl(msgid, IPC_RMID, NULL) == -1) {
        perror("msgctl");
        exit(1);
    }

    return 0;
}
