#include <stdio.h>

#include <stdlib.h>

#include <sys/shm.h>

#include <sys/types.h>

#include <unistd.h>


struct shared {

    char sel[100];

    int b;

};


int main() {

    int shmId;

    int fd[2]; // File descriptors for the pipe

    pid_t pid;

    struct shared *shmPtr;


    // Create the shared memory

    shmId = shmget(IPC_PRIVATE, sizeof(struct shared), IPC_CREAT | 0666);

    shmPtr = (struct shared *)shmat(shmId, NULL, 0);


    // Initialize balance

    shmPtr->b = 1000;


    // Create a pipe

    if (pipe(fd) < 0) {

        perror("pipe error");

        exit(1);

    }


    printf("Provide Your Input From Given Options:\n");

    printf("1. Type a to Add Money\n");

    printf("2. Type w to Withdraw Money\n");

    printf("3. Type c to Check Balance\n");

    scanf("%s", shmPtr->sel);

    printf("Your selection: %s\n", shmPtr->sel);


    // Fork the child process

    if ((pid = fork()) == 0) {

        // Child process

        int amount;

            // Child process operations based on selection

        if (shmPtr->sel[0] == 'a') {

            printf("\nEnter amount to be added:\n");

            scanf("%d", &amount);

            if (amount > 0) {

                shmPtr->b += amount;

                printf("Balance added successfully\n");

                printf("Updated balance after addition: %d\n", shmPtr->b);

            } else {

                printf("Adding failed, Invalid amount\n");

            }

        } else if (shmPtr->sel[0] == 'w') {

            printf("\nEnter amount to be withdrawn:\n");

            scanf("%d", &amount);

            if (amount > 0 && amount <= shmPtr->b) {

                shmPtr->b -= amount;

                printf("Withdrawal successful\n");

                printf("Updated balance after withdrawal: %d\n", shmPtr->b);

            } else {

                printf("Withdrawal failed, Invalid amount\n");

            }

        } else if (shmPtr->sel[0] == 'c') {

            printf("Current balance: %d\n", shmPtr->b);

        } else {

            printf("Invalid selection\n");

        }


        // Write a closing message to the pipe

        char message[] = "Thank you for using";

        write(fd[1], message, sizeof(message));

        

        // Close the write-end of the pipe in the child process

        close(fd[1]);


        // Detach from the shared memory

        shmdt(shmPtr);


        // Child process exits

        exit(0);

    } else {

        // Parent process waits for the child to complete

        wait(NULL);


        // Close the write-end of the pipe in the parent process

        close(fd[1]);


        // Read the closing message from the pipe

        char readBuffer[100];

        read(fd[0], readBuffer, sizeof(readBuffer));

        printf("%s\n", readBuffer);


        // Close the read-end of the pipe

        close(fd[0]);


        // Detach from and remove the shared memory

        shmdt(shmPtr);

        shmctl(shmId, IPC_RMID, NULL);

    }


    return 0;

}
